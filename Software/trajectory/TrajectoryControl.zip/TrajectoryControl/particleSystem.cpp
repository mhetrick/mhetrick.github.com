/*
 *  particleSystem.cpp
 *  TrajectoryControl
 *
 *  Created by Michael Hetrick on 2/8/11.
 *
 */

#include "particleSystem.h"
#include "math.h"
#include "lo/lo.h"
#include <iostream>

const int MAX_PARTICLES = 1000;
int NUM_PARTICLES = 1000; 
bool testOutput = false;
//particle myParticles[MAX_PARTICLES]; //create an array of particles for the system


particleSystem::particleSystem(float x, float y, float z){
	initX = x;
	initY = y;
	initZ = z;
	initParticles(); //initialize all particles in the system
	systemCounter = 0;
}


void particleSystem::initParticles(){
	for(int i = 0; i<MAX_PARTICLES; i++){
		myParticles[i].initParticle(initX, initY, initZ);
	}
}


void particleSystem::runSystem(void* t){
	for(int i = 0; i<systemCounter; i++){
		
		//draw and update every active particle
		myParticles[i].drawParticle();
		myParticles[i].updateParticle();
		
		
		//SEND OSC MESSAGES
			float myAzimuth = myParticles[i].calcAzimuth();
			float myDistance = myParticles[i].calcDistance();
			//format OSC messages (new SES)
			char particleAddress[sizeof("/SpatDIF/source/999/aed")];
			sprintf(particleAddress, "/SpatDIF/source/%d/aed", (i+1));
			//send out OSC messages!		
			if(lo_send(t, particleAddress, "fff", myAzimuth, 0.0, myDistance) == -1){
				printf("OSC error %d: %s\n", lo_address_errno(t), lo_address_errstr(t));
			}
			//test the output
			if (testOutput) {
				std::cout << i+1 << " " <<  myAzimuth << " "  << myDistance << std::endl;
			}
		
		
		//collision detection
		for (int j = 0; j<systemCounter; j++) {
			if (i != j) {
				
				
				//get positions of two particles
				float ball1x = myParticles[i].getXPosition();
				float ball1y = myParticles[i].getYPosition();
				float ball2x = myParticles[j].getXPosition();
				float ball2y = myParticles[j].getYPosition();
				float diffX = ball1x - ball2x;
				float diffY = ball1y - ball2y;
				float radius1 = myParticles[i].getParticleSize();
				float radius2 = myParticles[j].getParticleSize();
				
				//calculate distance between particles
				float particleDistance = sqrt(diffX*diffX + diffY*diffY);
				if (particleDistance <= radius1 + radius2) { //collision
					
					float ball1VelocityX = myParticles[i].getXVelocity();
					float ball1VelocityY = myParticles[i].getYVelocity();
					float ball1Mass = myParticles[i].getParticleSize();
					
					float ball2VelocityX = myParticles[j].getXVelocity();
					float ball2VelocityY = myParticles[j].getYVelocity();
					float ball2Mass = myParticles[j].getParticleSize();
					
					//angles of impact
					float diffTheta = atan2(diffY, diffX);
					float diffSine = sin(diffTheta);
					float diffCosine = cos(diffTheta);
					
//					float ball1tempXPos;
//					float ball1tempYPos;
//					float ball2tempXPos = diffCosine*diffX + diffSine*diffY;
//					float ball2tempYPos = diffCosine*diffY - diffSine*diffX;
					
					//rotate temporary velocities
					float ball1tempXVel = diffCosine*ball1VelocityX + diffSine*ball1VelocityY;
					float ball1tempYVel = diffCosine*ball1VelocityY - diffSine*ball1VelocityX;
					float ball2tempXVel = diffCosine*ball2VelocityX + diffSine*ball2VelocityY;
					float ball2tempYVel = diffCosine*ball2VelocityY - diffSine*ball2VelocityX;
					
					
					float ball1newXVel = ((ball1Mass - ball2Mass) * ball1tempXVel + 2 * ball2Mass
										  * ball2tempXVel)/(ball1Mass + ball2Mass);
					float ball1newYVel = ball1tempYVel;
					float ball2newXVel = ((ball2Mass - ball1Mass) * ball2tempXVel + 2 * ball1Mass
										  * ball1tempXVel)/(ball2Mass + ball1Mass);
					float ball2newYVel = ball2tempYVel;
					
//					ball1tempXPos = ball1x + ball1newXVel;
//					ball2tempXPos = ball2x + ball2newXVel;
					
//					float ball1finalX = diffCosine * ball1tempXPos - diffSine * ball1tempYPos;
//					float ball1finalY = diffCosine * ball1tempYPos + diffSine * ball1tempXPos;
//					float ball2finalX = diffCosine * ball2tempXPos - diffSine * ball2tempYPos;
//					float ball2finalY = diffCosine * ball2tempYPos + diffSine * ball2tempXPos;
					
					ball1VelocityX = diffCosine*ball1newXVel - diffSine*ball1newYVel;
					ball1VelocityY = diffCosine*ball1newYVel + diffSine*ball1newXVel;
					ball2VelocityX = diffCosine*ball2newXVel - diffSine*ball2newYVel;
					ball2VelocityY = diffCosine*ball2newYVel + diffSine*ball2newXVel;
					
					
					
					
					myParticles[i].setVelocity(ball1VelocityX, ball1VelocityY, 0.0);
					//myParticles[i].setPosition(ball1finalX, ball1finalY, initZ);
					myParticles[j].setVelocity(ball2VelocityX, ball2VelocityY, 0.0);
					//myParticles[j].setPosition(ball2finalX, ball2finalY, initZ);
				}
			}
		}
	}
	
	//increase particle count until all particles are initialized
	if (systemCounter<NUM_PARTICLES) {
		systemCounter++;
	}
}


void particleSystem::setNumParticles(int numParticles){
	NUM_PARTICLES = numParticles;
}

void particleSystem::setSystemAcceleration(float accX, float accY, float accZ){
	for(int i = 0; i<NUM_PARTICLES; i++){
		myParticles[i].setAccel(accX, accY, accZ);
	}
}

void particleSystem::setIndividualAcceleration(int particleNum, float accX, float accY, float accZ){
		myParticles[particleNum].setAccel(accX, accY, accZ);
}

void particleSystem::setIndividualVelocity(int particleNum, float velX, float velY, float velZ){
	myParticles[particleNum].setVelocity(velX, velY, velZ);
}

void particleSystem::setIndividualFrequency(int particleNum, float frequency){
	myParticles[particleNum].setFrequency(frequency);
}

void particleSystem::setIndividualSize(int particleNum, float size){
	myParticles[particleNum].setParticleSize(size);
}


void particleSystem::setIndividualColors(int particleNum, float r, float g, float b){
	myParticles[particleNum].setColors(r, g, b);
}

void particleSystem::setIndividualDistance(int particleNum, float newDistance){
	myParticles[particleNum].setDistance(newDistance);
}


float particleSystem::getIndividualFrequency(int particleNum){
	float newFreq = myParticles[particleNum].getFrequency();
	return newFreq;
}

float particleSystem::getPositionX(int particleNum){
	float myX = myParticles[particleNum].getXPosition();
	return myX;
}

float particleSystem::getPositionY(int particleNum){
	float myY = myParticles[particleNum].getYPosition();
	return myY;
}
