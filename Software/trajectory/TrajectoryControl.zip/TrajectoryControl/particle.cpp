/*
 *  particle.cpp
 *  TrajectoryControl
 *
 *  Created by Michael Hetrick on 2/6/11.
 *
 */

#include <stdlib.h>
#include "particle.h"
#include <stdio.h>
#include <GLUT/glut.h>
#include <math.h>
#include <iostream>
//#include <SOIL.h>
#include "lo/lo.h"
//#include "Gamma/AudioIO.h"
//#include "Gamma/Oscillator.h"

const float PI = 3.141592;

//particle lifespan and size
float particleSize = 1.0;
int maxLifespan = 1000;
int spreadAmount = 100;	//sets maximum spread
int maxVelocity = 100;
float bounceFactor = -1.0;
float distanceMult = 1.0;

//colors for all particles (if colorful = false)
float mainR = 0.5;
float mainG = 0.0;
float mainB = 1.0;

//arena boundaries
float maxX = 50.0;
float maxY = 40.0;
float maxZ = -50.0;
float mainZ;

//particle init conditions
bool colorful = true;	//activate random colors
bool threeD = false;	//activate z-motion
bool onePoint = false;	//activate initial spread

//activate OSC
//bool oscSend = true;
//bool newSES = true;
//bool testOutput = false;

//activate timer options
bool lifeFade = false;	//activate lifetime fade
bool resetInit = false;	//reset particles to starting point
bool resetTimer = true;
bool vacuumMode = false;


/////////////
//constructor
/////////////
particle::particle(){
	
}


/////////////
//polar calcs
/////////////

float particle::calcAzimuth(){
	float x = position[0];
	float y = position[1];
	
	float azimuth = 360.0 - ( (atan2(y, x) + (1.5*PI)) * (180.0/PI) );
	
	return azimuth;
}

float particle::calcDistance(){
	float x = position[0];
	float y = position[1];
	
	float myDistance = (sqrt((pow(x, 2.0)) + (pow(y, 2.0))))*distanceMult;
	
	return myDistance;	
}


////
//set functions
////
void particle::setColors(float r, float g, float b){
	colors[0] = r;
	colors[1] = g;
	colors[2] = b;
}

void particle::setPosition(float x, float y, float z){
	position[0] = x;
	position[1] = y;
	position[2] = z;
}

void particle::setInitPosition(float x, float y, float z){
	initPosition[0] = x;
	initPosition[1] = y;
	initPosition[2] = z;
}

void particle::setVelocity(float x, float y, float z){
	velocity[0] = x;
	velocity[1] = y;
	velocity[2] = z;
}

void particle::setAccel(float accX, float accY, float accZ){
	accel[0] = accX;
	accel[1] = accY;
	accel[2] = accZ;
}

void particle::setFrequency(float freq){
	frequency = freq;
}

void particle::setParticleSize(float size){
	particleSize = size;
}

void particle::setDistance(float newDistance){
	distanceMult = newDistance;
}


float particle::getFrequency(){
	return frequency;
}

float particle::getXPosition(){
	return position[0];
}

float particle::getYPosition(){
	return position[1];
}

float particle::getXVelocity(){
	return velocity[0];
}

float particle::getYVelocity(){
	return velocity[1];
}

float particle::getParticleSize(){
	return particleSize;
}

//////
//init
//////
void particle::initParticle(float initX, float initY, float initZ){
	//lifespan timer
	timer = 0;
	frequency = 40.0;
	
	//set initial position
	setInitPosition(initX, initY, initZ);
	mainZ = initZ;
	
	
	//acceleration
	setAccel(0.0000, -0.000, 0.0);
	
	
	//colors
	if (colorful) {
		setColors(((rand() % 10)/10.0), ((rand() % 10)/10.0), ((rand() % 10)/10.0));
	}else{
		setColors(mainR, mainG, mainB);
	}
	
	
	//positions
	if (onePoint) {
		setPosition(initX, initY, initZ);
	}else{
		setPosition(initX + randomSpread(), initY + randomSpread(), initZ);
	}
	
	
	//velocities
	if (threeD) {
		setVelocity(randomVelocity(), randomVelocity(), randomVelocity());
	} else{
		setVelocity(randomVelocity(), randomVelocity(), 0.0);
	}
}

float particle::randomSpread(){
	float spread = (((rand() % (spreadAmount*2))-spreadAmount)/10.0);
	return spread;
}

float particle::randomVelocity(){
	float velocity = (((rand() % (maxVelocity*2))-maxVelocity)/1000.0);
	return velocity;
}

void particle::checkBoundaries(){
	//x boundary
	if (position[0] >= maxX - particleSize) {
		position[0] = maxX - particleSize;
		reverseVelocity(0);
	}
	if (position[0] <= (-1.0*maxX) + particleSize) {
		position[0] = (-1.0 * maxX) + particleSize;
		reverseVelocity(0);
	}
	
	//y boundary
	if (position[1] >= maxY - particleSize) {
		position[1] = maxY - particleSize;
		reverseVelocity(1);
	}
	if (position[1] <= (-1.0*maxY) + particleSize) {
		position[1] = (-1.0 * maxY) + particleSize;
		reverseVelocity(1);
	}
	
	//z boundary
	if (position[2] >= maxZ) {
		position[2] = maxZ;
		reverseVelocity(2);
	}
	if (position[2] <= (mainZ)) {
		position[2] = mainZ;
		reverseVelocity(2);
	}
}

void particle::reverseVelocity(int velIndex){
	velocity[velIndex] *= bounceFactor;
}

void particle::updateParticle(){
	
	for (int i=0; i<3; i++) {
		velocity[i] += accel[i]; //adds acceleration to velocity
		position[i] += velocity[i]; //updates position with new velocity
	}
	//int myAddress, void *t
//	//SEND OSC MESSAGES
//	if (oscSend == true) {
//		float myAzimuth = calcAzimuth(position[0], position[1]);
//		float myDistance = calcDistance(position[0], position[1]);
//		if (newSES){
//			//format OSC messages (new SES)
//			char particleAddress[sizeof("/SpatDIF/source/999/aed")];
//			sprintf(particleAddress, "/SpatDIF/source/%d/aed", (myAddress+1));
//			//send out OSC messages!		
//			if(lo_send(t, particleAddress, "fff", myAzimuth, 0.0, myDistance) == -1){
//				printf("OSC error %d: %s\n", lo_address_errno(t), lo_address_errstr(t));
//			}
//		}else {
//			//format OSC messages (old SES)
//			char particleAddress[sizeof("/SpatDIF/source/999/aed")];
//			sprintf(particleAddress, "/SpatDIF/source/%d/aed", myAddress+1);
//			//send out OSC messages!		
//			if(lo_send(t, "/Element", "ifff", (myAddress+1),  0.0, myAzimuth, myDistance) == -1){
//				printf("OSC error %d: %s\n", lo_address_errno(t), lo_address_errstr(t));
//			}
//		}
//		//test the output
//		if (testOutput) {
//			std::cout << myAddress+1 << " " <<  myAzimuth << " "  << myDistance << std::endl;
//		}
//	}
	
	checkBoundaries();
	
	//TIMER FUNCTIONS
	this-> timer += 1;
	if (timer>maxLifespan) {
		if (resetInit) {
			initParticle(initPosition[0], initPosition[1], initPosition[2]);
		}
		if (resetTimer) {
			timer = 0; //use this line for strobe light effect
		}
		if (vacuumMode) {
			velocity[0] *= -1.0; //use these two for funky vacuum
			velocity[1] *= -1.0;
		}
	}
	
}

//////
//draw
//////
void particle::drawParticle(){
	glPushMatrix();
	
	if (lifeFade) {
		glColor4f(colors[0], colors[1], colors[2], (maxLifespan-timer)/maxLifespan); //fading brightness
	}else{
		glColor4f(colors[0], colors[1], colors[2], 1.0); //constant brightness
	}
	
	glBegin(GL_QUADS);		//begin shape
	
	glTexCoord2f(0, 0);
	glVertex3f(position[0]-particleSize, position[1]-particleSize, position[2]);	//draw each vertex
	
	glTexCoord2f(1, 0);
	glVertex3f(position[0]+particleSize, position[1]-particleSize, position[2]);
	
	glTexCoord2f(1, 1);
	glVertex3f(position[0]+particleSize, position[1]+particleSize, position[2]);
	
	glTexCoord2f(0, 1);
	glVertex3f(position[0]-particleSize, position[1]+particleSize, position[2]);
	glEnd();				//end shape
	
	
//	glBegin(GL_POINTS);
//	glVertex3f(position[0], position[1], position[2]);
//	glEnd();
	
	glPopMatrix();
}