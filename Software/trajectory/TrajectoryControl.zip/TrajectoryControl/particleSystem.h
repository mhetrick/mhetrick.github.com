/*
 *  particleSystem.h
 *  TrajectoryControl
 *
 *  Created by Michael Hetrick on 2/8/11.
 *
 */

#include "particle.h"

/////////////////
//Particle System
/////////////////
class particleSystem{
	
private:
	int systemCounter;
	float initX;
	float initY;
	float initZ;
	
public:
	particle myParticles[1000];
	particleSystem(float x, float y, float z);
	void initParticles();
	void runSystem(void* oscAddress);
	
	void setNumParticles(int numParticles);
	void setSystemAcceleration(float accX, float accY, float accZ);
	void setIndividualAcceleration(int particleNum, float accX, float accY, float accZ);
	void setIndividualVelocity(int particleNum, float velX, float velY, float velZ);
	void setIndividualFrequency(int particleNum, float frequency);
	void setIndividualSize(int particleNum, float size);
	void setIndividualColors(int particleNum, float r, float g, float b);
	void setIndividualDistance(int particleNum, float newDistance);
	
	float getIndividualFrequency(int particleNum);
	float getPositionX(int particleNum);
	float getPositionY(int particleNum);
};