/*
 *  particle.h
 *  TrajectoryControl
 *
 *  Created by Michael Hetrick on 2/6/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

class particle{

private:
	float timer;
	float colors[3]; //holds r g b
	float initPosition[3];	//position x y z
	float position[3];	//position x y z
	float velocity[3];	//velocity x y z
	float accel[3];	//gravity x y z
	float frequency;
	float particleSize;
	float distanceMult;
	
public:

	particle();
	
	float calcAzimuth();
	float calcDistance();
	
	void setColors(float r, float g, float b);
	void setPosition(float x, float y, float z);
	void setInitPosition(float x, float y, float z);
	void setVelocity(float x, float y, float z);
	void setAccel(float accX, float accY, float accZ);
	void setFrequency(float freq);
	void setParticleSize(float size);
	void setDistance(float newDistance);
	float getFrequency();
	float getXPosition();
	float getYPosition();
	float getXVelocity();
	float getYVelocity();
	float getParticleSize();

	float randomSpread();
	float randomVelocity();
	
	void initParticle(float initX, float initY, float initZ);
	void checkBoundaries();
	void reverseVelocity(int velIndex);
	void updateParticle();
	
	void drawParticle();
};