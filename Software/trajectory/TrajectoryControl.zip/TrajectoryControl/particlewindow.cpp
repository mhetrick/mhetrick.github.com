/*	Graphics Library of Views (GLV) - GUI Building Toolkit
 See COPYRIGHT file for authors and license information */

#include <stdlib.h>
#include <stdio.h>
#include <GLUT/glut.h>
#include <math.h>
#include <SOIL.h>
#include "lo/lo.h"
#include <iostream> 
#include "particleSystem.h"
#include "test_glv.h"
#include "glv_sliders.h"
#include "Gamma/AudioIO.h"
#include "Gamma/Oscillator.h"
#include "Gamma/Delay.h"
using namespace glv;
using namespace gam;

Window win(640, 480, "Trajectory Controller");

const int numParticles = 8;
const int numChannels = 8;
int count=0;
float accelIntensity = 500.0;

//setup OSC
lo_address oscAddress;
char ipAddress[sizeof("000.000.000.000")];
char portAddress[sizeof("10000")];

//setup particle system
particleSystem thisSystem(0, 0, -94); //create a public system for the drawing loop


//GLV stuff
Slider2D velSliders2[numParticles];
Slider2D accSliders2[numParticles];
Slider freqSliders[numParticles] = Slider(Rect(20, 40));
Slider freqFineSliders[numParticles] = Slider(Rect(20, 40));
Slider filtSliders[numParticles];
Slider resSliders[numParticles];
Slider volSliders[numParticles];
Sliders fmSliders[numParticles] = Sliders(Rect(40, 40), numParticles, 1, false);
Sliders colorSliders[numParticles] = Sliders(Rect(40, 40), 3, 1, true);
Slider sizeSliders[numParticles];
Slider distanceSliders[numParticles];
Buttons waveformSelect[numParticles];
Button oscActive[numParticles];
Button resetDevice = Button(Rect(10, 10), true);
NumberDialer myIP[4] = NumberDialer(Rect(10,10), 3, 0);
NumberDialer myPort = NumberDialer(Rect(10,10), 5, 0);
NumberDialer myOutput = NumberDialer(Rect(10,10), 2, 0);

Button toolBar[numParticles];					//particle selector
Button setVel(Rect(40,40), true);

Placer layout;	//main layout, attached to GLV, receives widgets


//gamma stuff
Sine<> sineBank[numParticles];
Saw<> sawBank[numParticles];
Square<> squareBank[numParticles];
Biquad<> filters[numParticles];
float audioData[numParticles];
float myFreq[numParticles];
int myCounter = 0;

void audioCB(AudioIOData& io);
AudioIO io(256, 44100., audioCB, NULL, numChannels, numChannels);
AudioDevice sFlower(3);

///////////////
//Texture Load
///////////////
GLuint tex;
void loadTextures(){
	tex = SOIL_load_OGL_texture("/Users/Tricky/Dropbox/Programming/XCode/Glut/Particle.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y);
	
	if (0 == tex) {
		printf("SOIL Loading error: '%s' \n", SOIL_last_result());
	}
}

void drawSubView(){
	
}


void drawCB(View * v, GLV& g){
	
	using namespace draw;
	
	if(200==count) win.show(); ++count;
	
	push3D(v->w, v->h);
	
	///////////
	//particles
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE); //turn on alpha blending
	glBindTexture(GL_TEXTURE_2D, tex);
	
	//glEnable(GL_POINT_SPRITE);
	//glTexEnvi(GL_POINT_SPRITE, GL_COORD_REPLACE, GL_TRUE);
	
	thisSystem.runSystem(oscAddress);
	glBindTexture(GL_TEXTURE_2D, NULL);
	//cout << myFreq[0] << std::endl;

	pop3D();
	
	color(1);
	text(
		 "esc  toggle full screen\n"
		 "  d  change audio device\n"
		 "  o  set new osc address\n"
		 "  q  quit",
		 8, 150
		 );
	

	//set velocities and accelerations
	for (int p = 0; p<numParticles; p++) {
			if (setVel.getValue()) {
				thisSystem.setIndividualVelocity(p, velSliders2[p].getValue(0), velSliders2[p].getValue(1), 0.0);
			}
		thisSystem.setIndividualAcceleration(p, (accSliders2[p].getValue(0))/accelIntensity, (accSliders2[p].getValue(1))/accelIntensity, 0.0);
		thisSystem.setIndividualSize(p, sizeSliders[p].getValue());
		thisSystem.setIndividualColors(p, colorSliders[p].getValue(0), colorSliders[p].getValue(1), colorSliders[p].getValue(2));
		thisSystem.setIndividualDistance(p, distanceSliders[p].getValue());
	}
	
	
}

void drawControls(View * v, GLV& g){
	using namespace draw;
	
	if(200==count) win.show(); ++count;
}


void changeDevice(){
	io.close();

	io.deviceOut(myOutput.getValue());
	io.channelsOut(8);
	
	io.start();
	io.print();
	cout << "Output changed to: " << myOutput.getValue() << " Channels: " << io.channelsOutDevice() << " out of: " << io.channelsOut() <<std::endl;
}

void setOscAddress(){
	//set IP address and port
	sprintf(ipAddress, "%d.%d.%d.%d", (int) myIP[0].getValue(), (int) myIP[1].getValue(), (int) myIP[2].getValue(), (int) myIP[3].getValue());
	sprintf(portAddress, "%d", (int) myPort.getValue());
	//cout << ipAddress << " port: " << portAddress << std::endl;
	
	oscAddress = lo_address_new(ipAddress, portAddress);
}


bool evKeyDown(View * v, GLV& g){
	switch(g.keyboard().key()){
		case Key::Escape: win.fullScreenToggle(); break;
		//case 'h': ; break;
		case 's': win.show(); break;
		case 'q': Application::quit(); break;
		case 'd':changeDevice(); break;
		case 'o':setOscAddress(); break;
		default:;
	}
	return false;
}

bool evWinResize(View * v, GLV& g){ printf("Event::WindowResize\n"); return false; }
bool evWinCreate(View * v, GLV& g){ printf("Event::WindowCreate\n"); return false; }
bool evWinDestroy(View * v, GLV& g){ printf("Event::WindowDestroy\n"); return false; }
bool evQuit(View * v, GLV& g){ printf("Event::Quit\n"); return false; }



////////////////
//sound callback
////////////////
void audioCB(AudioIOData& io){
	while(io()){	//sound is on
		for (int i = 0; i<numParticles; i++) {
			
			if (waveformSelect[i].getValue(0)) {	//switch between sin, saw, square
				sineBank[i].freq(myFreq[i]);		//set frequency of oscillator
				audioData[i] = sineBank[i]();		//grab audio data
			}else if (waveformSelect[i].getValue(1)) {
				sawBank[i].freq(myFreq[i]);
				audioData[i] = sawBank[i]();
			}else if (waveformSelect[i].getValue(2)) {
				squareBank[i].freq(myFreq[i]);
				audioData[i] = squareBank[i]();
			}
			
			
			myFreq[i] = freqSliders[i].getValue(0) + freqFineSliders[i].getValue(0 );				//set base frequency
			
			if (toolBar[i].getValue()) {						//check if particle is on
				filters[i].res(resSliders[i].getValue(0));		//set filter resonance
				
				for (int m =0; m < numParticles; m++) {			//cycle all modulators
					if (toolBar[m].getValue()) {
						myFreq[i] += (fmSliders[m].getValue(i) * (audioData[m] + .001));
					}
				}
				
									//apply new frequency
				filters[i].freq(filtSliders[i].getValue(0));	//set filter frequency
				float myOutput = filters[i](audioData[i]);		//create output data
				
				//io.out(i%numChannels) += myOutput * volSliders[i].getValue(0);
				io.out(i) += myOutput * volSliders[i].getValue(0);
			
				//myCounter++;
			}
		}
	}
}

int main(){
	AudioDevice::printAll();
	loadTextures();
	thisSystem.setNumParticles(numParticles);
	
		
	glEnable(GL_TEXTURE_2D);
	
	//particle window
	GLV glv(drawCB);
	//glv.colors().set(StyleColor::Gray);
	glv.colors().set(HSV(0.3,0.,0.6), 0.55);
	glv(Event::KeyDown, evKeyDown);
	glv(Event::WindowResize, evWinResize);
	glv(Event::WindowCreate, evWinCreate);
	glv(Event::WindowDestroy, evWinDestroy);
	glv(Event::Quit, evQuit);
	win.setGLV(glv);
	
	//control window
	Window controlWin(500, 565, "Controls");
	controlWin.position(640,0);
	GLV controlGLV(drawControls);
	controlGLV(Event::KeyDown, evKeyDown);
	controlWin.setGLV(controlGLV);
	
	////////////////
	//woo, interface
	////////////////
	Placer layout(controlGLV, Direction::E, Place::TL, 10, 330, 10);
	
	Label setLabel("set velocity", false);
	Label accLabel("acceleration", false);
	Label freqLabel("osc frequency (coarse/fine)", false);
	Label filtLabel("filter cutoff", false);
	Label resLabel("filter resonance", false);
	Label volLabel("channel volume", false);
	Label fmLabel("fm", false);
	Label waveLabel("sine/saw/square", false);
	Label sizeLabel("particle size", false);
	Label distanceLabel("distance multiplier", false);
	Label colorLabel("particle rgb", false);
	Label ipLabel("ip address", false);
	Label oscLabel("osc active", false);
	Label portLabel("port", false);
	Label outputLabel("output device (see console)", false);
	

	//Button Bar
	layout.pos(0, 0).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		char c[] = {'A' + i, 0};
		toolBar[i].disable(DrawBack | FocusHighlight).extent(40, 20);
		layout << (toolBar[i] << (new Label(c))->anchor(Place::CC).pos(Place::CC));
	}
	
	
	//Velocity Bar
	layout.pos(0, 20).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		velSliders2[i] = Slider2D(Rect(40, 40), 0, 0, 4);
		velSliders2[i].interval(0.5, -0.5);
		layout << velSliders2[i];
	}
	layout << setVel << setLabel;
	
	
	//Acceleration Bar
	layout.pos(0, 60).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		accSliders2[i] = Slider2D(Rect(40, 40), 0, 0, 4);
		accSliders2[i].interval(1.0, -1.0);
		layout << accSliders2[i];
	}
	layout << accLabel;
	
	
	//Frequency Bar
	layout.pos(0, 100).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		freqSliders[i].interval(40.0, 2000.0);
		freqFineSliders[i].interval(-100.0, 100.0);
		freqSliders[i].setValue(40.0);
		layout << freqSliders[i];
		layout << freqFineSliders[i];
	}
	layout << freqLabel;
	
	
	//Cutoff Bar
	layout.pos(0, 140).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		filtSliders[i] = Slider(Rect(40, 40));
		filtSliders[i].interval(200.0, 3000.0);
		filtSliders[i].setValue(1000.0);
		layout << filtSliders[i];
	}
	layout << filtLabel;
	
	
	//Resonance Bar
	layout.pos(0, 180).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		resSliders[i] = Slider(Rect(40, 40));
		resSliders[i].interval(1.0, 80.0);
		resSliders[i].setValue(4.0);
		layout << resSliders[i];
	}
	layout << resLabel;
	
	
	//Volume Bar
	layout.pos(0, 220).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		volSliders[i] = Slider(Rect(40, 40));
		volSliders[i].interval(0.0, 1.0);
		volSliders[i].setValue(0.3);
		layout << volSliders[i];
	}
	layout << volLabel;
	
	
	//FM Bar
	layout.pos(0, 260).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		fmSliders[i].interval(0.0, 400.0);
		layout << fmSliders[i];
	}
	layout << fmLabel;
	
	
	//Waveform Bar
	layout.pos(0, 300).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		waveformSelect[i] = Buttons(Rect(40, 40), 3, 1, false, true);
		waveformSelect[i].setValue(1, 1);
		layout << waveformSelect[i];
	}
	layout << waveLabel;
	
	
	//Size Bar
	layout.pos(0, 340).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		sizeSliders[i] = Slider(Rect(40, 40));
		sizeSliders[i].interval(0.5, 10.0);
		sizeSliders[i].setValue(1.0);
		layout << sizeSliders[i];
	}
	layout << sizeLabel;
	
	
	//color Bar
	layout.pos(0, 380).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		colorSliders[i].interval(0.0, 1.0);
		layout << colorSliders[i];
		colorSliders[i].setValue(((float)i/(float)numParticles), 2, 0);
		colorSliders[i].setValue((numParticles-i)/10.0, 1, 0);
	}
	layout << colorLabel;
	
	
	//distance Bar
	layout.pos(0, 420).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<numParticles; ++i){
		distanceSliders[i] = Slider(Rect(40, 40));
		distanceSliders[i].interval(0.01, 1.0);
		layout << distanceSliders[i];
		distanceSliders[i].setValue(0.5);
	}
	layout << distanceLabel;
	
	
//	//osc Bar
//	layout.pos(0, 460).flow(Direction::E, 0).align(Place::TL);
//	for(int i=0; i<numParticles; ++i){
//		oscActive[i] = Button(Rect(40, 40));
//		oscActive[i].setValue(1.0);
//		layout << oscActive[i];
//	}
//	layout << oscLabel;
	
	
	//ip Address and port
	layout.pos(0, 520).flow(Direction::E, 0).align(Place::TL);
	for(int i=0; i<4; ++i){
		layout << myIP[i];
	}
	myIP[0].setValue(127);
	myIP[1].setValue(0);
	myIP[2].setValue(0);
	myIP[3].setValue(1);
	layout << ipLabel;
	layout << myPort;
	myPort.setValue(7770);
	layout << portLabel;
	
	
	//audio device
	layout.pos(0, 540).flow(Direction::E, 0).align(Place::TL);
	layout << myOutput;
	myOutput.interval(0, AudioDevice::numDevices()-1);
	layout << outputLabel;
	//layout << resetDevice;
	

	/////////////
	//whoa, sound
	/////////////
	//AudioIO io(256, 44100., audioCB, NULL, numChannels);
	Sync::master().spu(io.framesPerSecond());
	io.channelsOut(16);
	io.start();
	
	setOscAddress();
	io.print();
	Application::run();
}
