/*
 *  particleSystem.cpp
 *  TrajectoryControl
 *
 *  Created by Michael Hetrick on 2/8/11.
 *
 */

#include "particleSystem.h"

const int MAX_PARTICLES = 1000;
int NUM_PARTICLES = 8; 
//particle myParticles[MAX_PARTICLES]; //create an array of particles for the system


particleSystem::particleSystem(float x, float y, float z){
	initX = x;
	initY = y;
	initZ = z;
	initParticles(); //initialize all particles in the system
	systemCounter = 0;
}


void particleSystem::initParticles(){
	for(int i = 0; i<NUM_PARTICLES; i++){
		myParticles[i].initParticle(initX, initY, initZ);
	}
}


void particleSystem::runSystem(void* oscAddress){
	for(int i = 0; i<systemCounter; i++){
		myParticles[i].drawParticle();
		myParticles[i].updateParticle(i, oscAddress);
	}
	
	if (systemCounter<NUM_PARTICLES) {
		systemCounter++;
	}
}


void particleSystem::setNumParticles(int numParticles){
	NUM_PARTICLES = numParticles;
}