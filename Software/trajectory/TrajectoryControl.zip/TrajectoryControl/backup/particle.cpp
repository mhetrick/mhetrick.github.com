/*
 *  particle.cpp
 *  TrajectoryControl
 *
 *  Created by Michael Hetrick on 2/6/11.
 *
 */

#include <stdlib.h>
#include "particle.h"
#include <stdio.h>
#include <GLUT/glut.h>
#include <math.h>
#include <SOIL.h>
#include "lo/lo.h"

const float PI = 3.141592;

//particle lifespan and size
float particleSize = 1.0;
int maxLifespan = 1000;
int spreadAmount = 50;	//sets maximum spread
int maxVelocity = 100;
float bounceFactor = -1.0;

//colors for all particles (if colorful = false)
float mainR = 0.5;
float mainG = 0.0;
float mainB = 1.0;

//arena boundaries
float maxX = 50.0;
float maxY = 40.0;
float maxZ = -50.0;

//particle init conditions
bool colorful = true;	//activate random colors
bool threeD = false;	//activate z-motion
bool onePoint = true;	//activate initial spread

//activate OSC
bool oscSend = false;
bool newSES = true;

//activate timer options
bool lifeFade = false;	//activate lifetime fade
bool resetInit = false;	//reset particles to starting point
bool resetTimer = true;
bool vacuumMode = false;


/////////////
//constructor
/////////////
particle::particle(){
	
}


/////////////
//polar calcs
/////////////

float particle::calcAzimuth(float x, float y){
	
	float azimuth = 360.0 - ( (atan2(y, x) + (1.5*PI)) * (180.0/PI) );
	
	return azimuth;
}

float particle::calcDistance(float x, float y){
	
	float myDistance = sqrt((pow(x, 2.0)) + (pow(y, 2.0)));
	
	return myDistance;	
}


////
//set functions
////
void particle::setColors(float r, float g, float b){
	colors[0] = r;
	colors[1] = g;
	colors[2] = b;
}

void particle::setPosition(float x, float y, float z){
	position[0] = x;
	position[1] = y;
	position[2] = z;
}

void particle::setInitPosition(float x, float y, float z){
	initPosition[0] = x;
	initPosition[1] = y;
	initPosition[2] = z;
}

void particle::setVelocity(float x, float y, float z){
	velocity[0] = x;
	velocity[1] = y;
	velocity[2] = z;
}

void particle::setAccel(float accX, float accY, float accZ){
	accel[0] = accX;
	accel[1] = accY;
	accel[2] = accZ;
}

//////
//init
//////
void particle::initParticle(float initX, float initY, float initZ){
	//lifespan timer
	timer = 0;
	
	//set initial position
	setInitPosition(initX, initY, initZ);
	
	//acceleration
	setAccel(0.0000, -0.000, 0.0);
	
	
	//colors
	if (colorful) {
		setColors(((rand() % 10)/10.0), ((rand() % 10)/10.0), ((rand() % 10)/10.0));
	}else{
		setColors(mainR, mainG, mainB);
	}
	
	
	//positions
	if (onePoint) {
		setPosition(initX, initY, initZ);
	}else{
		setPosition(initX + randomSpread(), initY + randomSpread(), initZ);
	}
	
	
	//velocities
	if (threeD) {
		setVelocity(randomVelocity(), randomVelocity(), randomVelocity());
	} else{
		setVelocity(randomVelocity(), randomVelocity(), 0.0);
	}
}

float particle::randomSpread(){
	float spread = (((rand() % (spreadAmount*2))-spreadAmount)/10.0);
	return spread;
}

float particle::randomVelocity(){
	float velocity = (((rand() % (maxVelocity*2))-maxVelocity)/1000.0);
	return velocity;
}

void particle::checkBoundaries(){
	//x boundary
	if (position[0] >= maxX || position[0] <= (-1.0*maxX)) {
		velocity[0] *= bounceFactor;
	}
	
	//y boundary
	if (position[1] >= maxY || position[1] <= (-1.0*maxY)) {
		velocity[1] *= bounceFactor;
	}
	
	//z boundary
	if (position[2] >= maxZ || position[2] <= maxZ-100) {
		velocity[2] *= bounceFactor;
	}
}

void particle::updateParticle(int myAddress, void *t){
	
	for (int i=0; i<3; i++) {
		velocity[i] += accel[i]; //adds acceleration to velocity
		position[i] += velocity[i]; //updates position with new velocity
	}
	
	//SEND OSC MESSAGES
	if (oscSend == true) {
		if (newSES){
			//format OSC messages (new SES)
			char particleAddress[sizeof("/SpatDIF/source/999/aed")];
			sprintf(particleAddress, "/SpatDIF/source/%d/aed", (myAddress+1));
			//send out OSC messages!		
			if(lo_send(t, particleAddress, "fff", calcAzimuth(position[0], position[1]), 0.0, calcDistance(position[0], position[1])/6.0) == -1){
				printf("OSC error %d: %s\n", lo_address_errno(t), lo_address_errstr(t));
			}
		}else {
			//format OSC messages (old SES)
			//char particleAddress[sizeof("/SpatDIF/source/999/aed")];
			//sprintf(particleAddress, "/SpatDIF/source/%d/aed", myAddress);
			//send out OSC messages!		
			if(lo_send(t, "/Element", "ifff", (myAddress+1),  0.0, calcAzimuth(position[0], position[1]), (calcDistance(position[0], position[1])/60.0)) == -1){
				printf("OSC error %d: %s\n", lo_address_errno(t), lo_address_errstr(t));
			}
		}
		//test the output
		//cout << myAddress << " " <<  calcAzimuth(position[0], position[1]) << " "  << (calcDistance(position[0], position[1])/60.0) << endl;
	}
	
	checkBoundaries();
	
	//TIMER FUNCTIONS
	this-> timer += 1;
	if (timer>maxLifespan) {
		if (resetInit) {
			initParticle(initPosition[0], initPosition[1], initPosition[2]);
		}
		if (resetTimer) {
			timer = 0; //use this line for strobe light effect
		}
		if (vacuumMode) {
			velocity[0] *= -1.0; //use these two for funky vacuum
			velocity[1] *= -1.0;
		}
	}
	
}

//////
//draw
//////
void particle::drawParticle(){
	glPushMatrix();
	
	if (lifeFade) {
		glColor4f(colors[0], colors[1], colors[2], (maxLifespan-timer)/maxLifespan); //fading brightness
	}else{
		glColor4f(colors[0], colors[1], colors[2], 1.0); //constant brightness
	}
	
	glBegin(GL_QUADS);		//begin shape
	
	glTexCoord2f(0, 0);
	glVertex3f(position[0]-particleSize, position[1]-particleSize, position[2]);	//draw each vertex
	
	glTexCoord2f(1, 0);
	glVertex3f(position[0]+particleSize, position[1]-particleSize, position[2]);
	
	glTexCoord2f(1, 1);
	glVertex3f(position[0]+particleSize, position[1]+particleSize, position[2]);
	
	glTexCoord2f(0, 1);
	glVertex3f(position[0]-particleSize, position[1]+particleSize, position[2]);
	glEnd();				//end shape
	glPopMatrix();
}