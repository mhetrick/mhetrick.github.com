/*
 *  particleSystem.h
 *  TrajectoryControl
 *
 *  Created by Michael Hetrick on 2/8/11.
 *
 */

#include "particle.h"

/////////////////
//Particle System
/////////////////
class particleSystem{
	
private:
	int systemCounter;
	float initX;
	float initY;
	float initZ;
	
public:
	particle myParticles[1000];
	particleSystem(float x, float y, float z);
	void initParticles();
	void runSystem(void* oscAddress);
	void setNumParticles(int numParticles);
};