/*
 *  Trajectory Control
 *  240B
 *
 *  Created by Michael Hetrick on 1/30/11.
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <GLUT/glut.h>
#include <math.h>
#include <SOIL.h>
#include "lo/lo.h"
#include <GLV/glv.h>
#include <iostream> 
#include "particleSystem.h"

using namespace std;

//setup OSC
lo_address oscAddress = lo_address_new("192.168.0.114", "7770"); //OSC service

int frameRate = 30;

//////////////////////
//initialize particle system
//////////////////////
particleSystem thisSystem(0, 0, -100); //create a public system for the drawing loop


///////////////
//Texture Load
///////////////
GLuint tex;
void loadTextures(){
	tex = SOIL_load_OGL_texture("/Users/Tricky/Dropbox/Programming/XCode/Glut/Particle.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y);
	
	if (0 == tex) {
		printf("SOIL Loading error: '%s' \n", SOIL_last_result());
	}
}

/////////////
//DisplayLoop
/////////////
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	thisSystem.runSystem(oscAddress);
	
    glutSwapBuffers();
}


//////////////////
//Reshape Function
//////////////////
void reshape(int width, int height)
{
    glViewport(0, 0, width, height);	//create window
	glMatrixMode(GL_PROJECTION);		//
	glLoadIdentity();					//
	gluPerspective(45.0, (float)width/(float)height, .1, 100.0); //far plane is set to 100 units
	
}


///////////////
//Idle Function
///////////////
void idle(void)
{
    glutPostRedisplay();
}

GLvoid GLTimer(int value){
	
	glutTimerFunc(1000/frameRate, GLTimer, 0);
}

///////////////
//Init Function
///////////////
int main(int argc, char** argv) //THIS IS THE BARE MINIMUM OF A GLUT PROJECT
{
	//	lo_server_thread st = lo_server_thread_new("7770", osc_error);
	//	lo_server_thread_add_method(st, NULL, NULL, generic_handler, NULL);
	//	lo_server_thread_start(st);
	
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(640, 480);
    
    glutCreateWindow("Particle Fountain");
    
    glutDisplayFunc(display); //REGISTERS CALLBACK FUNCTIONS
    glutReshapeFunc(reshape); //RESIZING/VIEWPORT
    glutIdleFunc(idle);		  
	glClearColor(0.0,0.0,0.0,0.0);
	
	glShadeModel(GL_SMOOTH);
	glClearDepth(1.0);
	glDisable(GL_DEPTH_TEST);
	
	loadTextures();
	
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, tex);
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE); //turn on alpha blending
	
	glutTimerFunc(1000/frameRate, GLTimer, 0);
    glutMainLoop();
    return EXIT_SUCCESS;
}

