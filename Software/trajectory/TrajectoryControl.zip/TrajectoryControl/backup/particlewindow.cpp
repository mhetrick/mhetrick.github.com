/*	Graphics Library of Views (GLV) - GUI Building Toolkit
 See COPYRIGHT file for authors and license information */

#include <stdlib.h>
#include <stdio.h>
#include <GLUT/glut.h>
#include <math.h>
#include <SOIL.h>
#include "lo/lo.h"
#include <iostream> 
#include "particleSystem.h"
#include "test_glv.h"
using namespace glv;

Window win(640, 480, "Trajectory Controller");
int count=0;

//setup OSC
lo_address oscAddress = lo_address_new("192.168.0.114", "7770"); //OSC service

//setup particle system
particleSystem thisSystem(0, 0, -94); //create a public system for the drawing loop

///////////////
//Texture Load
///////////////
GLuint tex;
void loadTextures(){
	tex = SOIL_load_OGL_texture("/Users/Tricky/Dropbox/Programming/XCode/Glut/Particle.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y);
	
	if (0 == tex) {
		printf("SOIL Loading error: '%s' \n", SOIL_last_result());
	}
}


void drawCB(View * v, GLV& g){
	
	using namespace draw;
	
	if(200==count) win.show(); ++count;
	
	
	
	push3D(v->w, v->h);
	
	//static float ang=0;
	//translate(0,0,-1);
	
	///////////
	//particles
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE); //turn on alpha blending
	glBindTexture(GL_TEXTURE_2D, tex);
	thisSystem.runSystem(oscAddress);
	glBindTexture(GL_TEXTURE_2D, NULL);
	
	pop3D();
	
	color(0);
	text(
		 "esc  toggle full screen\n"
		 "  g  toggle game mode\n"
		 "  h  hide\n"
		 "  i  minimize\n"
		 "  c  show/hide cursor\n"
		 "  q  quit",
		 8, 8
		 );
}


bool evKeyDown(View * v, GLV& g){
	switch(g.keyboard().key()){
		case Key::Escape: win.fullScreenToggle(); break;
		case 'c': win.hideCursor(!win.hideCursor()); break;
		case 'g': win.gameModeToggle(); break;
		case 'h': win.hide(); count=0; break;
		case 'i': win.iconify(); count=0; break;
		case 's': win.show(); break;
		case 'q': Application::quit(); break;
		default:;
	}
	return false;
}

bool evWinResize(View * v, GLV& g){ printf("Event::WindowResize\n"); return false; }
bool evWinCreate(View * v, GLV& g){ printf("Event::WindowCreate\n"); return false; }
bool evWinDestroy(View * v, GLV& g){ printf("Event::WindowDestroy\n"); return false; }
bool evQuit(View * v, GLV& g){ printf("Event::Quit\n"); return false; }

int main(){
	
	loadTextures();
	
	glEnable(GL_TEXTURE_2D);

	
	
	
	GLV glv(drawCB);
	glv.colors().set(StyleColor::Gray);
	glv(Event::KeyDown, evKeyDown);
	glv(Event::WindowResize, evWinResize);
	glv(Event::WindowCreate, evWinCreate);
	glv(Event::WindowDestroy, evWinDestroy);
	glv(Event::Quit, evQuit);
	win.setGLV(glv);
	Application::run();
}

