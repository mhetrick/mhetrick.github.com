/*
 *  Trajectory Control
 *  240B
 *
 *  Created by Michael Hetrick on 1/30/11.
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <GLUT/glut.h>
#include <math.h>
#include <SOIL.h>
#include "lo.h"
//#include "portaudio.h"
#include <iostream> 

using namespace std;

const float PI = 3.141592; //define PI

lo_address t = lo_address_new("127.0.0.1", "7770"); //OSC service

const int NUM_PARTICLES = 4; 
int frameRate = 20;

//particle lifespan
int maxLifespan = 1000;

//colors for all particles (if colorful = false)
float mainR = 0.5;
float mainG = 0.0;
float mainB = 1.0;

//activate random colors
bool colorful = true;
//activate lifetime fade
bool lifeFade = false;
//activate z-motion
bool threeD = false;
//activate initial spread
bool onePoint = true;

/////////////
//polar calcs
/////////////

float calcAzimuth(float x, float y){

	float azimuth = ( (atan2(y, x) + PI) * (180.0/PI) );
	
	return azimuth;
}

float calcDistance(float x, float y){
	
	float myDistance = sqrt((pow(x, 2.0)) + (pow(y, 2.0)));
	
	return myDistance;	
}

////////////
//OSC Thread
////////////
//int generic_handler(const char *path, const char *types, lo_arg **argv,
//					int argc, void *data, void *user_data)
//{
//    int i;
//    printf("path: <%s>\n", path);
//    for (i=0; i<argc; i++) {
//		printf("arg %d '%c' ", i, types[i]);
//		lo_arg_pp(lo_type(types[i]), argv[i]);
//		printf("\n");
//    }
//    printf("\n");
//    fflush(stdout);
//	
//    return 1;
//}
//
//void osc_error(int num, const char *msg, const char *path)
//{
//    printf("liblo server error %d in path %s: %s\n", num, path, msg);
//    fflush(stdout);
//}

/////////////////
//particle struct
/////////////////
class particle{
	//float fade;
	float timer;
	
	float colors[3]; //holds r g b
	
	float initPosition[3];	//position x y z
	
	float position[3];	//position x y z
	
	float velocity[3];	//velocity x y z
	
	float accel[3];	//gravity x y z
	
public:
	particle(){
		
	}
	
	////
	//set functions
	////
	void setColors(float r, float g, float b){
		this -> colors[0] = r;
		this -> colors[1] = g;
		this -> colors[2] = b;
	}
	
	void setPosition(float x, float y, float z){
		this -> position[0] = x;
		this -> position[1] = y;
		this -> position[2] = z;
	}
	
	void setInitPosition(float x, float y, float z){
		this -> initPosition[0] = x;
		this -> initPosition[1] = y;
		this -> initPosition[2] = z;
	}
	
	void setVelocity(float x, float y, float z){
		this -> velocity[0] = x;
		this -> velocity[1] = y;
		this -> velocity[2] = z;
	}
	
	void setAccel(float x, float y, float z){
		this -> accel[0] = x;
		this -> accel[1] = y;
		this -> accel[2] = z;
	}
	
	//////
	//init
	//////
	void initParticle(float initX, float initY, float initZ){
		//lifespan timer
		this -> timer = 0;
		
		//set initial position
		this -> setInitPosition(initX, initY, initZ);
		
		//acceleration
		this -> setAccel(0.0, 0, 0);
		
		//colors
		if (colorful) {
			this -> setColors(((rand() % 10)/10.0), ((rand() % 10)/10.0), ((rand() % 10)/10.0));
		}else{
			this -> setColors(mainR, mainG, mainB);
		}
		
		//positions
		if (onePoint) {
			this -> setPosition(initX, initY, initZ);
		}else{
			this -> setPosition((((rand() % 100)-50)/10.0), (((rand() % 100)-50)/10.0), -100.0);
		}
		
		
		
		//velocities
		if (threeD) {
			this -> setVelocity(((rand() % 50)-25)/1000.0, ((rand() % 50)-25)/1000.0, ((rand() % 50)-25)/1000.0);
		} else{
			this -> setVelocity(((rand() % 50)-25)/1000.0, ((rand() % 50)-25)/1000.0, 0.0);
		}
	}
	
	void checkBoundaries(){
		//x boundary
		if (this -> position[0] >= 50.0 || this -> position[0] <= -50) {
			this -> velocity[0] *= -1.0;
		}
		
		//y boundary
		if (this -> position[1] >= 40.0 || this -> position[1] <= -40) {
			this -> velocity[1] *= -1.0;
		}
		
		//z boundary
		if (this -> position[2] >= -50.0 || this -> position[2] <= -150) {
			this -> velocity[2] *= -1.0;
		}
	}
	
	void updateParticle(int myAddress){
		
		
		
		for (int i=0; i<3; i++) {
			this -> velocity[i] += this-> accel[i]; //adds acceleration to velocity
			this -> position[i] += this-> velocity[i]; //updates position with new velocity
		}
		
//		//format OSC messages (new SES)
//		char particleAddress[sizeof("/SpatDIF/source/999/aed")];
//		sprintf(particleAddress, "/SpatDIF/source/%d/aed", myAddress);
//		//send out OSC messages!		
//		if(lo_send(t, particleAddress, "fff", calcAzimuth(position[0], position[1]), 0.0, calcDistance(position[0], position[1])) == -1){
//			printf("OSC error %d: %s\n", lo_address_errno(t), lo_address_errstr(t));
//		}
		
		//format OSC messages (old SES)
		//char particleAddress[sizeof("/SpatDIF/source/999/aed")];
		//sprintf(particleAddress, "/SpatDIF/source/%d/aed", myAddress);
		//send out OSC messages!		
		if(lo_send(t, "/Element", "ifff", (myAddress+1), calcAzimuth(position[0], position[1]), 45.0, (calcDistance(position[0], position[1])/60.0)) == -1){
			printf("OSC error %d: %s\n", lo_address_errno(t), lo_address_errstr(t));
		}
		
		//test the output
		//cout << myAddress << " " <<  calcAzimuth(position[0], position[1]) << " "  << (calcDistance(position[0], position[1])/60.0) << endl;
		
		
		
		checkBoundaries();
		
		this-> timer += 1;
		
		if (timer>maxLifespan) {
			//initParticle(this-> initPosition[0], this-> initPosition[1], this-> initPosition[2]);
			//timer = 0; //use this line for strobe light effect
			//this -> velocity[0] *= -1.0; //use these two for funky vacuum
			//this -> velocity[1] *= -1.0;
		}
		
	}
	
	//////
	//draw
	//////
	void drawParticle(){
		glPushMatrix();
		
		if (lifeFade) {
			glColor4f(this -> colors[0], this -> colors[1], this -> colors[2], (maxLifespan-timer)/maxLifespan); //fading brightness
		}else{
			glColor4f(this -> colors[0], this -> colors[1], this -> colors[2], 1.0); //constant brightness
		}
		
		glBegin(GL_QUADS);		//begin shape
		
		glTexCoord2f(0, 0);
		glVertex3f(this -> position[0]-1.0, this -> position[1]-1.0, this -> position[2]);	//draw each vertex
		
		glTexCoord2f(1, 0);
		glVertex3f(this -> position[0]+1.0, this -> position[1]-1.0, this -> position[2]);
		
		glTexCoord2f(1, 1);
		glVertex3f(this -> position[0]+1.0, this -> position[1]+1.0, this -> position[2]);
		
		glTexCoord2f(0, 1);
		glVertex3f(this -> position[0]-1.0, this -> position[1]+1.0, this -> position[2]);
		glEnd();				//end shape
		glPopMatrix();
	}
};

/////////////////
//Particle System
/////////////////
class particleSystem{
	int systemCounter;
	float initX;
	float initY;
	float initZ;
	
public:
	particle myParticles[NUM_PARTICLES]; //create an array of particles for the system
	
	
	particleSystem(float x, float y, float z){
		this -> initX = x;
		this -> initY = y;
		this -> initZ = z;
		initParticles(); //initialize all particles in the system
		this -> systemCounter = 0;
	}
	
	void initParticles(){
		
		for(int i = 0; i<NUM_PARTICLES; i++){
			myParticles[i].initParticle(this-> initX, this-> initY, this-> initZ);
		}
		
	}
	
	void runSystem(){
		
		for(int i = 0; i<systemCounter; i++){
			this -> myParticles[i].drawParticle();
			this -> myParticles[i].updateParticle(i);
		}
		
		if (systemCounter<NUM_PARTICLES) {
			this -> systemCounter++;
		}
		
	}
};



//////////////////////
//initialize particle system
//////////////////////
particleSystem thisSystem(0, 0, -100); //create a public system for the drawing loop
//particleSystem systemTwo(-10, -10, -50);

///////////////
//Texture Load
///////////////
GLuint tex;
void loadTextures(){
	tex = SOIL_load_OGL_texture("/Users/Tricky/Dropbox/Programming/XCode/Glut/Particle.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y);
	
	if (0 == tex) {
		printf("SOIL Loading error: '%s' \n", SOIL_last_result());
	}
}

/////////////
//DisplayLoop
/////////////
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	thisSystem.runSystem();
	//systemTwo.runSystem();
	
    glutSwapBuffers();
}


//////////////////
//Reshape Function
//////////////////
void reshape(int width, int height)
{
    glViewport(0, 0, width, height);	//create window
	glMatrixMode(GL_PROJECTION);		//
	glLoadIdentity();					//
	gluPerspective(45.0, (float)width/(float)height, .1, 100.0); //far plane is set to 100 units
	
}


///////////////
//Idle Function
///////////////
void idle(void)
{
    glutPostRedisplay();
}

GLvoid GLTimer(int value){
	
	glutTimerFunc(1000/frameRate, GLTimer, 0);
}

///////////////
//Init Function
///////////////
int main(int argc, char** argv) //THIS IS THE BARE MINIMUM OF A GLUT PROJECT
{
//	lo_server_thread st = lo_server_thread_new("7770", osc_error);
//	lo_server_thread_add_method(st, NULL, NULL, generic_handler, NULL);
//	lo_server_thread_start(st);
	
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(640, 480);
    
    glutCreateWindow("Particle Fountain");
    
    glutDisplayFunc(display); //REGISTERS CALLBACK FUNCTIONS
    glutReshapeFunc(reshape); //RESIZING/VIEWPORT
    glutIdleFunc(idle);		  
	glClearColor(0.0,0.0,0.0,0.0);
	
	glShadeModel(GL_SMOOTH);
	glClearDepth(1.0);
	glDisable(GL_DEPTH_TEST);
	
	loadTextures();
	
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, tex);
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE); //turn on alpha blending
	
	glutTimerFunc(1000/frameRate, GLTimer, 0);
    glutMainLoop();
    return EXIT_SUCCESS;
}

